There is a "main" function with hw2.py

It takes a filepath to the test files and then spits out the corresponding files. 

It'll look a little something like this -

main(r"C:\Users\Michael's  Laptop\Documents\design_analysis_algo_class\hw2_test_files\10_Random.txt")