package shop.ui;

public class UIError extends Error {
}
